Run locally: `npm install` then `npm run dev`. Build: `npm run build` (output in `dist/`).
