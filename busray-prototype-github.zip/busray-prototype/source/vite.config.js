import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // "./" makes the built site work on GitHub Pages (which serves from /repo-name/)
  base: "./",
  server: {
    port: 5173,
    open: true,
  },
});
