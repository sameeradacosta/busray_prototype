import React, { useState, useEffect } from "react";
import {
  Bus, MapPin, Search, Navigation, Clock, ChevronRight, ChevronLeft,
  User, Bell, Heart, Home, Map as MapIcon, LogOut, CreditCard,
  Check, AlertCircle, Bike, Car, Footprints, Settings, LayoutDashboard,
  Users, Route as RouteIcon, Activity, TrendingUp, Play, Square, RefreshCw,
  Star, Phone, ShieldCheck, ArrowRight, Pause,
  Wallet, QrCode, Landmark, PartyPopper, Info, Radio,
} from "lucide-react";

/* =========================================================================
   BUSRAY — prototype/demo data
   ========================================================================= */

const ROUTES = {
  "101": {
    id: "101", reg: "GOA-07-AB-1234", driver: "Rajesh Naik",
    from: "Colva Beach", to: "Kamat Hotel",
    via: ["Colva Beach", "Margao", "Maria Hall", "Kamat Hotel"],
    status: "Approaching", eta: 6, distanceKm: 2.1, passengers: 12, type: "Standard Bus",
  },
  "204": {
    id: "204", reg: "GOA-07-CD-4567", driver: "Suresh Fernandes",
    from: "Colva Beach", to: "Kamat Hotel",
    via: ["Colva Beach", "Margao", "Chicalim", "Kamat Hotel"],
    status: "On Route", eta: 14, distanceKm: 5.4, passengers: 8, type: "Express Bus",
  },
  "305": {
    id: "305", reg: "GOA-07-EF-7890", driver: "Vinayak Dessai",
    from: "Margao", to: "Kamat Hotel",
    via: ["Margao", "Kamat Hotel"],
    status: "On Route", eta: 22, distanceKm: 8.9, passengers: 5, type: "Mini Bus",
  },
};

const SAVED_ROUTES = [
  { name: "College → Home", from: "Margao", to: "Colva" },
  { name: "Home → College", from: "Colva", to: "Margao" },
];

const TRIPS = [
  { bus: "101", from: "Margao", to: "Kamat Hotel", time: "10:32 AM", when: "Today", status: "On Time" },
  { bus: "204", from: "Margao", to: "Panjim", time: "4:15 PM", when: "Yesterday", status: "On Time" },
];

const ADMIN_BUSES = [
  { bus: "101", reg: "GOA-07-AB-1234", driver: "Rajesh Naik", route: "Colva → Kamat Hotel", status: "Active" },
  { bus: "204", reg: "GOA-07-CD-4567", driver: "Suresh Fernandes", route: "Margao → Panjim", status: "Active" },
  { bus: "305", reg: "GOA-07-EF-7890", driver: "Vinayak Dessai", route: "Vasco → Margao", status: "Offline" },
];

const REVENUE_SERIES = [
  { month: "Mar", riders: 2210 }, { month: "Apr", riders: 2540 },
  { month: "May", riders: 2810 }, { month: "Jun", riders: 3005 },
  { month: "Jul", riders: 3120 }, { month: "Aug", riders: 3240 },
];

// Stylised (non-geographic) route path for the tracking map — 4 stops, 16 sample points
const ROUTE_PATH = [
  [60, 430], [78, 402], [96, 372], [118, 344], [140, 320], [150, 296],
  [140, 268], [118, 244], [128, 214], [160, 192], [196, 178], [220, 150],
  [206, 118], [224, 90], [260, 70], [300, 56],
];
const STOP_POINT_INDEX = [0, 5, 10, 15];

/* =========================================================================
   Shared bits
   ========================================================================= */

const STATUS_STYLES = {
  "On Time": { dot: "bg-emerald-500", text: "text-emerald-700", bg: "bg-emerald-50" },
  "Delayed": { dot: "bg-amber-500", text: "text-amber-700", bg: "bg-amber-50" },
  "Cancelled": { dot: "bg-rose-500", text: "text-rose-700", bg: "bg-rose-50" },
  "Tracking": { dot: "bg-sky-500", text: "text-sky-700", bg: "bg-sky-50" },
  "Offline": { dot: "bg-slate-400", text: "text-slate-600", bg: "bg-slate-100" },
  "Approaching": { dot: "bg-sky-500", text: "text-sky-700", bg: "bg-sky-50" },
  "On Route": { dot: "bg-teal-500", text: "text-teal-700", bg: "bg-teal-50" },
  "Active": { dot: "bg-emerald-500", text: "text-emerald-700", bg: "bg-emerald-50" },
  "Pending Admin Approval": { dot: "bg-amber-500", text: "text-amber-700", bg: "bg-amber-50" },
};

function StatusBadge({ status }) {
  const s = STATUS_STYLES[status] || STATUS_STYLES.Offline;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${s.bg} ${s.text}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {status}
    </span>
  );
}

function Logo({ dark }) {
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="brand-mark relative flex h-9 w-9 items-center justify-center rounded-xl">
        <Bus className="h-5 w-5 text-white" strokeWidth={2.5} />
        <span className="teal-dot absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full ring-2 ring-white" />
      </div>
      <span className={`font-display text-xl font-bold tracking-tight ${dark ? "text-white" : "text-ink"}`}>
        BUSRAY
      </span>
    </div>
  );
}

function ProtoTag({ children = "Prototype / Demo Data" }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-dashed border-slate-300 bg-white px-2.5 py-1 font-mono text-2xs uppercase tracking-wider text-slate-500">
      <Info className="h-3 w-3" /> {children}
    </span>
  );
}

function PrimaryButton({ children, onClick, className = "", icon: Icon, full }) {
  return (
    <button
      onClick={onClick}
      className={`btn-primary inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 font-semibold shadow-sm transition active:scale-95 ${full ? "w-full" : ""} ${className}`}
    >
      {children}
      {Icon && <Icon className="h-4 w-4" />}
    </button>
  );
}

function GhostButton({ children, onClick, className = "", icon: Icon, full, small }) {
  return (
    <button
      onClick={onClick}
      className={`btn-ghost inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition active:scale-95 ${small ? "px-3 py-1.5 text-xs" : "px-5 py-3"} ${full ? "w-full" : ""} ${className}`}
    >
      {children}
      {Icon && <Icon className="h-4 w-4" />}
    </button>
  );
}

/* =========================================================================
   Landing Page
   ========================================================================= */

function RibbonAnimation() {
  const d = "M10,180 C 90,180 90,60 170,60 S 250,180 330,180 S 410,40 490,40 S 540,90 550,90";
  return (
    <svg viewBox="0 0 560 220" className="w-full">
      <path d={d} fill="none" stroke="#E7DFD1" strokeWidth="10" strokeLinecap="round" />
      <path d={d} fill="none" stroke="#3FA79A" strokeWidth="4" strokeDasharray="2 14" strokeLinecap="round" className="route-dash" />
      {[[10,180],[170,60],[330,180],[490,40]].map(([x,y],i)=>(
        <g key={i}>
          <circle cx={x} cy={y} r="6" fill="#141B2E" />
          <circle cx={x} cy={y} r="10" fill="none" stroke="#141B2E" strokeWidth="1.5" opacity="0.35" />
        </g>
      ))}
      <g>
        <circle r="16" fill="#C1502E" />
        <foreignObject x="-9" y="-9" width="18" height="18">
          <div style={{ width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Bus color="white" size={12} strokeWidth={3} />
          </div>
        </foreignObject>
        <animateMotion dur="7s" repeatCount="indefinite" path={d} />
      </g>
    </svg>
  );
}

function Landing({ go }) {
  return (
    <div className="min-h-screen bg-cream font-body text-ink">
      <header className="sticky top-0 z-30 border-b border-cream bg-cream">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <Logo />
          <nav className="hidden items-center gap-8 md:flex">
            <a href="#how" className="nav-link text-sm font-medium">How it works</a>
            <a href="#why" className="nav-link text-sm font-medium">Why BUSRAY</a>
            <a href="#pricing" className="nav-link text-sm font-medium">Pricing</a>
            <a href="#future" className="nav-link text-sm font-medium">Future scope</a>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => go("login", "driver")} className="nav-link hidden rounded-lg px-3 py-2 text-sm font-semibold sm:block">Driver login</button>
            <button onClick={() => go("login", "admin")} className="nav-link hidden rounded-lg px-3 py-2 text-sm font-semibold sm:block">Admin</button>
            <PrimaryButton onClick={() => go("login", "passenger")}>Passenger login</PrimaryButton>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl gap-10 px-5 pb-16 pt-14 md:grid-cols-2 md:items-center md:pt-20">
        <div>
          <span className="badge-ink mb-5 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold text-white">
            <Radio className="h-3.5 w-3.5 text-teal" /> Built for Goa's public buses
          </span>
          <h1 className="font-display text-5xl font-bold leading-tight tracking-tight text-ink sm:text-6xl">
            Know when your <span className="text-brand">bus</span> is coming.
          </h1>
          <p className="mt-5 max-w-md text-lg leading-relaxed text-slate-600">
            BUSRAY helps you discover, track and catch public buses across Goa — without waiting endlessly at the bus stop.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <PrimaryButton onClick={() => go("login", "passenger")} icon={ArrowRight}>Find a Bus</PrimaryButton>
            <GhostButton onClick={() => go("login", "passenger")} icon={MapIcon}>Track a Bus</GhostButton>
          </div>
          <div className="mt-8 flex items-center gap-6 text-sm text-slate-500">
            <div><span className="font-display text-2xl font-bold text-ink">128</span> buses live</div>
            <div className="h-8 w-px bg-cream-border" />
            <div><span className="font-display text-2xl font-bold text-ink">4,820</span> students on board</div>
          </div>
        </div>

        <div className="relative">
          <div className="card-surface rounded-3xl p-5 shadow-xl">
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-xs uppercase tracking-wider text-slate-400">Live route ribbon</span>
              <ProtoTag />
            </div>
            <RibbonAnimation />
            <div className="badge-ink mt-2 flex items-center justify-between rounded-2xl px-4 py-3 text-white">
              <div>
                <div className="text-xs text-white-60">Bus approaching</div>
                <div className="font-semibold">Colva → Margao</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-2xl font-bold text-teal">6 min</div>
                <div className="text-2xs text-white-50">away</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="how" className="border-y border-cream bg-white py-16">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="font-display text-3xl font-bold text-ink">How BUSRAY works</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { n: "01", t: "Choose your destination", d: "Tell us where you're starting from and where you're headed." },
              { n: "02", t: "Find nearby buses", d: "See every bus running your route, ranked by arrival time." },
              { n: "03", t: "Track your bus", d: "Watch it move on the map with a live ETA and next stop." },
              { n: "04", t: "Reach your destination", d: "Board on time, or switch to an alternative if it's too far off." },
            ].map((s) => (
              <div key={s.n} className="card-surface rounded-2xl p-5">
                <div className="font-mono text-sm font-semibold text-brand">{s.n}</div>
                <div className="mt-3 font-display text-lg font-bold text-ink">{s.t}</div>
                <div className="mt-2 text-sm leading-relaxed text-slate-600">{s.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="why" className="py-16">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="font-display text-3xl font-bold text-ink">Why BUSRAY?</h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              ["Real-time bus tracking", Navigation],
              ["Estimated arrival times", Clock],
              ["Nearby bus discovery", MapPin],
              ["Route information", RouteIcon],
              ["Alternative transport suggestions", Car],
              ["Student-friendly pricing", Wallet],
            ].map(([t, Icon]) => (
              <div key={t} className="card-surface flex items-center gap-3 rounded-xl px-4 py-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-cream">
                  <Icon className="h-5 w-5 text-brand" />
                </div>
                <span className="font-medium text-ink">{t}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="pricing" className="border-y border-cream bg-ink py-16">
        <div className="mx-auto max-w-3xl px-5 text-center">
          <h2 className="font-display text-3xl font-bold text-white">Simple. Affordable. Built for students.</h2>
          <div className="mx-auto mt-8 max-w-sm rounded-3xl bg-white p-8">
            <div className="font-mono text-5xl font-bold text-ink">₹9<span className="text-lg font-medium text-slate-400">/month</span></div>
            <ul className="mt-6 space-y-2 text-left text-sm text-slate-600">
              {["Real-time bus tracking","Bus ETA & nearby buses","Route & bus stop info","Alternative transport suggestions"].map(f=>(
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-teal" />{f}</li>
              ))}
            </ul>
            <PrimaryButton full className="mt-6" onClick={() => go("login", "passenger")}>Get BUSRAY</PrimaryButton>
          </div>
        </div>
      </section>

      <section id="future" className="py-16">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 md:grid-cols-2">
          <div className="card-surface rounded-2xl p-6">
            <h3 className="font-display text-xl font-bold text-ink">Future scope</h3>
            <p className="mt-2 text-sm text-slate-600">Beyond local Goa buses, BUSRAY could expand into:</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {["Inter-state buses","Airport shuttles","College shuttles","Digital ticketing","QR scanning","AI arrival prediction","Emergency SOS","Multi-language support"].map(f=>(
                <span key={f} className="rounded-full bg-cream px-3 py-1 text-xs font-medium text-slate-600">{f}</span>
              ))}
            </div>
          </div>
          <div className="card-surface rounded-2xl p-6">
            <h3 className="font-display text-xl font-bold text-ink">Business model</h3>
            <p className="mt-2 text-sm text-slate-600">Passenger subscription: <span className="font-semibold text-ink">₹9/month.</span> At 50 subscribers, that's ₹450/month · ₹5,400/year.</p>
            <p className="mt-3 text-sm text-slate-600">For bus operators: <span className="font-semibold text-amber-700">Future Business Model — Under Evaluation</span> (subscription, commission, B2B partnerships, or advertising).</p>
          </div>
        </div>
      </section>

      <footer className="border-t border-cream bg-white py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 sm:flex-row">
          <Logo />
          <div className="flex flex-wrap items-center justify-center gap-4 text-sm font-medium">
            <button onClick={() => go("login", "passenger")} className="nav-link">Passenger login</button>
            <button onClick={() => go("login", "driver")} className="nav-link">Driver login</button>
            <button onClick={() => go("login", "admin")} className="nav-link">Admin login</button>
          </div>
        </div>
        <div className="mx-auto mt-6 max-w-6xl px-5">
          <p className="rounded-xl bg-cream px-4 py-3 text-xs leading-relaxed text-slate-500">
            <strong>Prototype notice:</strong> BUSRAY is currently a prototype. Bus locations, ETAs and payment information shown in this demo are simulated and do not represent live transportation data.
          </p>
        </div>
      </footer>
    </div>
  );
}

/* =========================================================================
   Login / Signup
   ========================================================================= */

function Login({ go, roleTab, setRoleTab }) {
  const demo = {
    passenger: { id: "student@busray.demo", pass: "student123" },
    driver: { id: "driver@busray.demo", pass: "driver123" },
    admin: { id: "admin@busray.demo", pass: "admin123" },
  }[roleTab];

  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-5 py-10 font-body">
      <div className="w-full max-w-sm">
        <button onClick={() => go("landing")} className="nav-link mb-6 flex items-center gap-1 text-sm font-medium">
          <ChevronLeft className="h-4 w-4" /> Back to BUSRAY
        </button>
        <div className="mb-6"><Logo /></div>

        <div className="tabbar mb-6 grid grid-cols-3 gap-1 rounded-xl p-1">
          {["passenger", "driver", "admin"].map((r) => (
            <button
              key={r}
              onClick={() => setRoleTab(r)}
              className={`rounded-lg py-2 text-sm font-semibold capitalize transition ${roleTab === r ? "tab-active" : "text-slate-500"}`}
            >
              {r}
            </button>
          ))}
        </div>

        <div className="card-surface rounded-2xl p-6 shadow-sm">
          <h2 className="font-display text-xl font-bold capitalize text-ink">{roleTab} login</h2>
          <p className="mt-1 text-sm text-slate-500">
            {roleTab === "passenger" && "Track buses across Goa in seconds."}
            {roleTab === "driver" && "Start your trip and share your live location."}
            {roleTab === "admin" && "Manage buses, drivers, and routes."}
          </p>

          <div className="mt-5 space-y-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-500">{roleTab === "driver" ? "Driver ID / Phone" : "Email / Phone"}</label>
              <input defaultValue={demo.id} className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-500">Password</label>
              <input defaultValue={demo.pass} type="password" className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
            </div>
          </div>

          <PrimaryButton full className="mt-5" onClick={() => go(roleTab === "passenger" ? "passengerHome" : roleTab === "driver" ? "driverHome" : "adminHome")}>
            Login
          </PrimaryButton>
          {roleTab === "passenger" && (
            <button onClick={() => go("signup")} className="mt-3 w-full text-center text-sm font-semibold text-brand">Create account</button>
          )}
          <p className="mt-2 text-center text-xs text-slate-400">Forgot password?</p>

          <div className="mt-5 rounded-xl bg-cream px-3 py-2.5 text-xs text-slate-500">
            <span className="font-semibold text-slate-600">Demo account</span> — prefilled above. Just hit Login.
          </div>
        </div>
      </div>
    </div>
  );
}

function Signup({ go }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-5 py-10 font-body">
      <div className="w-full max-w-sm">
        <button onClick={() => go("login", "passenger")} className="nav-link mb-6 flex items-center gap-1 text-sm font-medium">
          <ChevronLeft className="h-4 w-4" /> Back to login
        </button>
        <div className="mb-6"><Logo /></div>
        <div className="card-surface rounded-2xl p-6 shadow-sm">
          <h2 className="font-display text-xl font-bold text-ink">Create your account</h2>
          <div className="mt-5 space-y-3">
            {["Full Name", "Email", "Mobile Number", "College"].map((f) => (
              <div key={f}>
                <label className="mb-1 block text-xs font-semibold text-slate-500">{f}</label>
                <input placeholder={f} className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-500">Password</label>
                <input type="password" className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-500">Confirm</label>
                <input type="password" className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
              </div>
            </div>
          </div>
          <label className="mt-4 flex items-start gap-2 text-xs text-slate-500">
            <input type="checkbox" defaultChecked className="mt-0.5" />
            I agree to the BUSRAY Terms &amp; Privacy Policy.
          </label>
          <PrimaryButton full className="mt-5" onClick={() => go("passengerHome")}>Create Account</PrimaryButton>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Passenger shell
   ========================================================================= */

const PASSENGER_TABS = [
  { key: "passengerHome", label: "Home", icon: Home },
  { key: "findBus", label: "Find Bus", icon: Search },
  { key: "tracking", label: "Map", icon: MapIcon },
  { key: "trips", label: "Trips", icon: Clock },
  { key: "profile", label: "Profile", icon: User },
];

function PassengerShell({ screen, go, notifOpen, setNotifOpen, children }) {
  return (
    <div className="min-h-screen bg-cream pb-20 font-body md:pb-0">
      <header className="sticky top-0 z-30 border-b border-cream bg-cream">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
          <button onClick={() => go("passengerHome")}><Logo /></button>
          <nav className="hidden items-center gap-6 md:flex">
            {[
              ["passengerHome", "Home"], ["findBus", "Find Bus"], ["trips", "My Trips"],
              ["saved", "Saved Routes"], ["subscription", "Subscription"], ["profile", "Profile"],
            ].map(([k, l]) => (
              <button key={k} onClick={() => go(k)} className={`text-sm font-medium ${screen === k ? "text-brand" : "nav-link"}`}>{l}</button>
            ))}
          </nav>
          <div className="relative flex items-center gap-3">
            <button onClick={() => setNotifOpen((v) => !v)} className="icon-btn relative rounded-full p-2">
              <Bell className="h-5 w-5 text-ink" />
              <span className="ping-dot absolute right-1.5 top-1.5 h-2 w-2 rounded-full" />
            </button>
            <button onClick={() => go("profile")} className="badge-ink flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white">SD</button>
            {notifOpen && (
              <div className="card-surface absolute right-0 top-12 w-72 rounded-xl p-2 shadow-lg">
                {[
                  "Your bus is 6 minutes away.",
                  "BUS 101 has reached Maria Hall.",
                  "Your bus is delayed by 8 minutes.",
                  "A new bus has been added to your saved route.",
                ].map((n, i) => (
                  <div key={i} className="flex gap-2 rounded-lg px-2 py-2 text-sm text-slate-600">
                    <Bell className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" /> {n}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-6">{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-30 flex border-t border-cream bg-white md:hidden">
        {PASSENGER_TABS.map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => go(key)} className="flex flex-1 flex-col items-center gap-1 py-2.5">
            <Icon className={`h-5 w-5 ${screen === key ? "text-brand" : "text-slate-400"}`} />
            <span className={`text-2xs font-medium ${screen === key ? "text-brand" : "text-slate-400"}`}>{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

/* =========================================================================
   Passenger Home
   ========================================================================= */

function PassengerHome({ go, search, setSearch }) {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Good afternoon 👋</h1>
      <p className="mt-1 text-slate-500">Where are you going?</p>

      <div className="card-surface mt-5 rounded-2xl p-5 shadow-sm">
        <div className="space-y-3">
          <div className="input-field flex items-center gap-3 rounded-xl px-3 py-3">
            <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-teal" />
            <input value={search.from} onChange={(e) => setSearch((s) => ({ ...s, from: e.target.value }))}
              placeholder="From — e.g. Margao" className="w-full bg-transparent text-sm outline-none" />
          </div>
          <div className="input-field flex items-center gap-3 rounded-xl px-3 py-3">
            <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-brand" />
            <input value={search.to} onChange={(e) => setSearch((s) => ({ ...s, to: e.target.value }))}
              placeholder="To — e.g. Kamat Hotel" className="w-full bg-transparent text-sm outline-none" />
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <PrimaryButton full onClick={() => go("busResults")} icon={Search}>Find Buses</PrimaryButton>
          <GhostButton full onClick={() => setSearch((s) => ({ ...s, from: "Current Location" }))} icon={Navigation}>Use My Location</GhostButton>
        </div>
      </div>

      <div className="mt-8 flex items-center justify-between">
        <h2 className="font-display text-lg font-bold text-ink">Buses near me</h2>
        <ProtoTag />
      </div>
      <div className="mt-3 space-y-3">
        {Object.values(ROUTES).map((b) => (
          <button key={b.id} onClick={() => go("tracking", null, b)} className="bus-row card-surface flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cream"><Bus className="h-5 w-5 text-brand" /></div>
              <div>
                <div className="font-semibold text-ink">BUS {b.id}</div>
                <div className="text-xs text-slate-500">{(b.distanceKm/2.5).toFixed(1)} km away</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-mono text-lg font-bold text-ink">{b.eta} min</div>
              <StatusBadge status={b.status} />
            </div>
          </button>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="font-display text-lg font-bold text-ink">Saved routes</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {SAVED_ROUTES.map((r) => (
            <div key={r.name} className="card-surface flex items-center justify-between rounded-xl px-4 py-3.5">
              <div className="flex items-center gap-3">
                <Heart className="h-4 w-4 fill-current text-brand" />
                <div>
                  <div className="text-sm font-semibold text-ink">{r.name}</div>
                  <div className="text-xs text-slate-500">{r.from} → {r.to}</div>
                </div>
              </div>
              <button onClick={() => { setSearch({ from: r.from, to: r.to }); go("busResults"); }} className="text-xs font-semibold text-brand">Track</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Find Bus results
   ========================================================================= */

function BusResults({ go, search }) {
  const list = Object.values(ROUTES);
  return (
    <div>
      <button onClick={() => go("passengerHome")} className="nav-link mb-3 flex items-center gap-1 text-sm font-medium"><ChevronLeft className="h-4 w-4" />Edit search</button>
      <h1 className="font-display text-2xl font-bold text-ink">{search.from || "Margao"} → {search.to || "Kamat Hotel"}</h1>
      <p className="mt-1 text-sm text-slate-500">{list.length} buses available</p>

      <div className="mt-5 space-y-4">
        {list.map((b) => (
          <div key={b.id} className="card-surface rounded-2xl p-5 shadow-sm">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className="badge-ink flex h-9 w-9 items-center justify-center rounded-lg font-mono text-xs font-bold text-white">{b.id}</span>
                <div>
                  <div className="font-display font-bold text-ink">{b.from} → {b.to}</div>
                  <div className="text-xs text-slate-500">Via {b.via.join(" → ")}</div>
                </div>
              </div>
              <StatusBadge status={b.status} />
            </div>
            <div className="mt-4 flex items-center justify-between rounded-xl bg-cream px-4 py-3">
              <div className="flex items-center gap-2 text-sm text-slate-600"><Bus className="h-4 w-4 text-brand" /> {b.eta} min away</div>
              <div className="font-mono text-xl font-bold text-ink">{b.eta} min</div>
            </div>
            <div className="mt-4 flex gap-2">
              <PrimaryButton full onClick={() => go("tracking", null, b)} icon={MapIcon}>Track Bus</PrimaryButton>
              <GhostButton onClick={() => go("alternative", null, b)}>Alternatives</GhostButton>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center">
        <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-cream"><Search className="h-5 w-5 text-slate-400" /></div>
        <div className="font-semibold text-ink">Not the route you meant?</div>
        <p className="mt-1 text-sm text-slate-500">We couldn't find a bus matching an exact route right now.</p>
        <div className="mt-3 flex justify-center gap-2">
          <GhostButton onClick={() => go("passengerHome")}>Try another route</GhostButton>
          <GhostButton onClick={() => go("passengerHome")}>View nearby buses</GhostButton>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Live Bus Tracking
   ========================================================================= */

function useGpsSimulation(active = true, speedMs = 1400) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => {
      setIdx((i) => (i + 1 >= ROUTE_PATH.length ? 0 : i + 1));
    }, speedMs);
    return () => clearInterval(t);
  }, [active, speedMs]);
  return idx;
}

function TrackingMap({ selectedBus, idx }) {
  const point = ROUTE_PATH[idx];
  const pathD = "M " + ROUTE_PATH.map((p) => p.join(",")).join(" L ");
  const stops = selectedBus?.via?.length ? selectedBus.via : ["Colva Beach", "Margao", "Maria Hall", "Kamat Hotel"];

  return (
    <div className="relative overflow-hidden rounded-2xl border border-cream bg-mapbg">
      <svg viewBox="0 0 360 480" className="w-full" style={{ height: 420 }}>
        <rect width="360" height="480" fill="#EFF5F2" />
        <path d="M0,460 Q 90,430 140,380 T 260,260 T 360,120" stroke="#D9E6E0" strokeWidth="26" fill="none" strokeLinecap="round" />
        <path d={pathD} stroke="#141B2E" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.15" />
        <path d={pathD} stroke="#3FA79A" strokeWidth="3" strokeDasharray="1 10" fill="none" strokeLinecap="round" className="route-dash" />
        {STOP_POINT_INDEX.map((pi, i) => {
          const [x, y] = ROUTE_PATH[pi];
          const passed = idx >= pi;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r="7" fill={passed ? "#141B2E" : "#fff"} stroke="#141B2E" strokeWidth="2" />
              <foreignObject x={x - 60} y={i % 2 === 0 ? y - 26 : y + 10} width="120" height="18">
                <div style={{ textAlign: "center", fontSize: 10, fontWeight: 600, color: "#141B2E", fontFamily: "IBM Plex Mono, monospace" }}>
                  {stops[i]}
                </div>
              </foreignObject>
            </g>
          );
        })}
        <g transform="translate(60,430)">
          <circle r="9" fill="#141B2E" />
          <circle r="9" fill="#141B2E" opacity="0.25">
            <animate attributeName="r" values="9;18;9" dur="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.25;0;0.25" dur="2s" repeatCount="indefinite" />
          </circle>
          <foreignObject x="-6" y="-6" width="12" height="12">
            <div style={{ width: 12, height: 12 }}><User color="white" size={9} /></div>
          </foreignObject>
        </g>
        <g transform={`translate(${point[0]},${point[1]})`} style={{ transition: "transform 1.2s linear" }}>
          <circle r="14" fill="#C1502E" />
          <foreignObject x="-8" y="-8" width="16" height="16">
            <div style={{ width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Bus color="white" size={11} strokeWidth={3} />
            </div>
          </foreignObject>
        </g>
      </svg>
      <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 text-2xs font-semibold text-ink shadow-sm">
        <span className="live-dot h-1.5 w-1.5 rounded-full" /> Live GPS Simulation
      </div>
      <div className="absolute right-3 top-3"><ProtoTag /></div>
    </div>
  );
}

function BusTracking({ go, selectedBus }) {
  const bus = selectedBus || ROUTES["101"];
  const [active, setActive] = useState(true);
  const idx = useGpsSimulation(active);
  const stops = bus.via;
  const passedStops = STOP_POINT_INDEX.filter((pi) => idx >= pi).length;
  const currentStop = stops[Math.max(0, passedStops - 1)];
  const nextStop = stops[Math.min(stops.length - 1, passedStops)];
  const remainingFrac = 1 - idx / (ROUTE_PATH.length - 1);
  const etaLive = Math.max(1, Math.round(bus.eta * remainingFrac));
  const distLive = Math.max(0.1, (bus.distanceKm * remainingFrac)).toFixed(1);
  const [flash, setFlash] = useState(false);

  return (
    <div>
      <button onClick={() => go("busResults")} className="nav-link mb-3 flex items-center gap-1 text-sm font-medium"><ChevronLeft className="h-4 w-4" />Back to results</button>
      <div className="grid gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2"><TrackingMap selectedBus={bus} idx={idx} /></div>

        <div className="space-y-4">
          <div className="card-surface rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="font-display text-lg font-bold text-ink">BUS {bus.id}</div>
              <StatusBadge status="Tracking" />
            </div>
            <div className="text-sm text-slate-500">{bus.from} → {bus.to}</div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-cream p-3">
                <div className="text-2xs font-semibold uppercase tracking-wide text-slate-400">ETA</div>
                <div className="font-mono text-3xl font-bold text-ink">{etaLive}<span className="text-sm font-medium text-slate-400"> min</span></div>
              </div>
              <div className="rounded-xl bg-cream p-3">
                <div className="text-2xs font-semibold uppercase tracking-wide text-slate-400">Distance</div>
                <div className="font-mono text-3xl font-bold text-ink">{distLive}<span className="text-sm font-medium text-slate-400"> km</span></div>
              </div>
            </div>

            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Current location</span><span className="font-semibold text-ink">Near {currentStop}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Next stop</span><span className="font-semibold text-ink">{nextStop}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Status</span><StatusBadge status="On Time" /></div>
              <div className="flex justify-between"><span className="text-slate-500">Last updated</span><span className="font-semibold text-ink">{flash ? "Just now ✓" : "Just now"}</span></div>
            </div>

            <div className="mt-4 flex gap-2">
              <GhostButton full icon={RefreshCw} onClick={() => { setFlash(true); setTimeout(() => setFlash(false), 900); }}>Refresh Location</GhostButton>
              <button onClick={() => setActive((a) => !a)} className="btn-ghost flex items-center justify-center rounded-xl px-3">
                {active ? <Pause className="h-4 w-4 text-ink" /> : <Play className="h-4 w-4 text-ink" />}
              </button>
            </div>
          </div>

          <div className="flex gap-2">
            <PrimaryButton full onClick={() => go("arrival", null, bus)}>Wait for Bus</PrimaryButton>
            <GhostButton full onClick={() => go("alternative", null, bus)}>Find Alternative</GhostButton>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Bus Arrival / ETA
   ========================================================================= */

function BusArrival({ go, selectedBus }) {
  const bus = selectedBus || ROUTES["101"];
  const stops = bus.via;
  const hereIndex = stops.length - 2 >= 0 ? 1 : 0;

  return (
    <div className="mx-auto max-w-md">
      <button onClick={() => go("tracking", null, bus)} className="nav-link mb-3 flex items-center gap-1 text-sm font-medium"><ChevronLeft className="h-4 w-4" />Back to map</button>
      <div className="card-surface rounded-2xl p-6 text-center shadow-sm">
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-cream"><Bus className="h-6 w-6 text-brand" /></div>
        <h1 className="font-display text-xl font-bold text-ink">Your bus is arriving soon</h1>
        <p className="mt-1 text-sm text-slate-500">{bus.to} Bus Stop</p>

        <div className="mt-5 font-mono text-5xl font-bold text-ink">{bus.eta}<span className="text-lg font-medium text-slate-400"> min</span></div>
        <div className="text-xs text-slate-500">BUS {bus.id} · {bus.distanceKm} km away</div>

        <div className="mt-6 space-y-0 text-left">
          {stops.map((s, i) => (
            <div key={s} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span className={`h-3 w-3 rounded-full ${i === hereIndex ? "bg-brand" : "bg-slate-300"}`} />
                {i < stops.length - 1 && <span className="h-8 w-px bg-slate-200" />}
              </div>
              <div className={`-mt-0.5 pb-6 text-sm ${i === hereIndex ? "font-bold text-ink" : "text-slate-500"}`}>
                {s} {i === hereIndex && <span className="tag-brand-soft ml-1 rounded-full px-2 py-0.5 text-2xs font-semibold">You are here</span>}
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-xl bg-cream px-4 py-2.5 text-sm text-slate-600">Next stop: <span className="font-semibold text-ink">{stops[hereIndex + 1] || stops[stops.length - 1]}</span></div>

        <div className="mt-5 flex gap-2">
          <PrimaryButton full onClick={() => go("tracking", null, bus)}>Keep Tracking</PrimaryButton>
          <GhostButton full onClick={() => go("alternative", null, bus)}>Too long?</GhostButton>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Alternative transport
   ========================================================================= */

function AlternativeTransport({ go, selectedBus }) {
  const bus = selectedBus || ROUTES["305"];
  const options = [
    { icon: Footprints, name: "Walk", time: "18 min", cost: "₹0", cta: "Walk" },
    { icon: Bike, name: "Bike / Pilot", time: "7 min", cost: "₹50–₹80", cta: "Find Pilot" },
    { icon: Car, name: "Cab", time: "8 min", cost: "₹120–₹180", cta: "Book Cab" },
  ];
  const [pilotShown, setPilotShown] = useState(false);

  return (
    <div className="mx-auto max-w-lg">
      <button onClick={() => go("tracking", null, bus)} className="nav-link mb-3 flex items-center gap-1 text-sm font-medium"><ChevronLeft className="h-4 w-4" />Back</button>
      <h1 className="font-display text-2xl font-bold text-ink">Need to get there sooner?</h1>
      <p className="mt-1 text-sm text-slate-500">Destination: <span className="font-semibold text-ink">{bus.to}</span> · BUS {bus.id} is {bus.eta} min away</p>

      <div className="mt-5 space-y-3">
        {options.map((o) => (
          <div key={o.name} className="card-surface flex items-center justify-between rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-cream"><o.icon className="h-5 w-5 text-brand" /></div>
              <div>
                <div className="font-semibold text-ink">{o.name}</div>
                <div className="text-xs text-slate-500">{o.time} · {o.cost}</div>
              </div>
            </div>
            <button onClick={() => o.name === "Bike / Pilot" ? setPilotShown(true) : null} className="badge-ink rounded-lg px-3.5 py-2 text-xs font-semibold text-white">{o.cta}</button>
          </div>
        ))}
      </div>

      {pilotShown && (
        <div className="card-surface mt-4 rounded-2xl p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Nearby Pilot</span>
            <ProtoTag />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-cream font-bold text-ink">R</div>
              <div>
                <div className="font-semibold text-ink">Ravi</div>
                <div className="flex items-center gap-1 text-xs text-slate-500"><Star className="h-3 w-3 fill-current text-amber-400" /> 4.8 · ₹60 approx.</div>
              </div>
            </div>
            <button className="btn-ghost flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold"><Phone className="h-3.5 w-3.5" /> Call</button>
          </div>
          <p className="mt-2 text-2xs text-slate-400">Demo contact — not a real service.</p>
        </div>
      )}

      <PrimaryButton full className="mt-5" onClick={() => go("tracking", null, bus)}>Actually, I'll wait for the bus</PrimaryButton>
    </div>
  );
}

/* =========================================================================
   Trips / Saved / Subscription / Profile
   ========================================================================= */

function MyTrips() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">My Trips</h1>
      <div className="mt-4 space-y-3">
        {TRIPS.map((t, i) => (
          <div key={i} className="card-surface flex items-center justify-between rounded-xl px-4 py-3.5">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cream font-mono text-xs font-bold text-ink">{t.bus}</div>
              <div>
                <div className="text-sm font-semibold text-ink">{t.from} → {t.to}</div>
                <div className="text-xs text-slate-500">{t.when} · {t.time}</div>
              </div>
            </div>
            <StatusBadge status={t.status} />
          </div>
        ))}
      </div>
    </div>
  );
}

function SavedRoutesScreen({ go, setSearch }) {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Saved Routes</h1>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {SAVED_ROUTES.map((r) => (
          <div key={r.name} className="card-surface rounded-xl p-4">
            <div className="flex items-center gap-2"><Heart className="h-4 w-4 fill-current text-brand" /><span className="font-semibold text-ink">{r.name}</span></div>
            <div className="mt-1 text-sm text-slate-500">{r.from} → {r.to}</div>
            <div className="mt-3 flex gap-2">
              <GhostButton small onClick={() => { setSearch({ from: r.from, to: r.to }); go("busResults"); }}>Track</GhostButton>
              <GhostButton small>Edit</GhostButton>
              <GhostButton small>Delete</GhostButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Subscription({ subActive, setSubActive }) {
  const [step, setStep] = useState(subActive ? "active" : "pick");
  const [method, setMethod] = useState("UPI");

  return (
    <div className="mx-auto max-w-md">
      <h1 className="font-display text-2xl font-bold text-ink">BUSRAY Pass</h1>

      {step === "active" ? (
        <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-6 text-center">
          <PartyPopper className="mx-auto h-8 w-8 text-emerald-600" />
          <h2 className="mt-2 font-display text-lg font-bold text-emerald-800">Subscription Activated 🎉</h2>
          <p className="mt-1 text-sm text-emerald-700">Your BUSRAY Pass is active until <strong>September 20, 2026</strong>.</p>
          <p className="mt-3 text-2xs text-emerald-600">Prototype Payment — No real transaction</p>
        </div>
      ) : (
        <>
          <div className="card-surface mt-5 rounded-2xl p-6 text-center shadow-sm">
            <div className="font-mono text-4xl font-bold text-ink">₹9<span className="text-base font-medium text-slate-400">/month</span></div>
            <ul className="mt-4 space-y-1.5 text-left text-sm text-slate-600">
              {["Real-time bus tracking","Bus ETA","Nearby buses","Route discovery","Bus stop information","Alternative transport suggestions"].map(f => (
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-teal" />{f}</li>
              ))}
            </ul>
          </div>

          {step === "pick" && (
            <PrimaryButton full className="mt-4" onClick={() => setStep("pay")}>Subscribe for ₹9/month</PrimaryButton>
          )}

          {step === "pay" && (
            <div className="card-surface mt-4 rounded-2xl p-5 shadow-sm">
              <div className="text-sm font-semibold text-ink">Choose Payment Method</div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                {[["UPI", QrCode], ["Card", CreditCard], ["Net Banking", Landmark]].map(([m, Icon]) => (
                  <button key={m} onClick={() => setMethod(m)} className={`flex flex-col items-center gap-1.5 rounded-xl border px-2 py-3 text-xs font-semibold ${method === m ? "pay-active" : "border-slate-200 text-slate-500"}`}>
                    <Icon className="h-5 w-5" />{m}
                  </button>
                ))}
              </div>
              <PrimaryButton full className="mt-4" onClick={() => { setSubActive(true); setStep("active"); }}>Pay ₹9</PrimaryButton>
              <p className="mt-2 text-center text-2xs text-slate-400">Prototype Payment — No real transaction</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Profile({ go, subActive }) {
  return (
    <div className="mx-auto max-w-md">
      <h1 className="font-display text-2xl font-bold text-ink">Profile</h1>
      <div className="card-surface mt-4 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="badge-ink flex h-14 w-14 items-center justify-center rounded-full text-lg font-bold text-white">SD</div>
          <div>
            <div className="font-display text-lg font-bold text-ink">Sofia D'Souza</div>
            <div className="text-sm text-slate-500">sofia@busray.demo</div>
          </div>
        </div>
        <div className="mt-5 space-y-3 text-sm">
          <div className="flex justify-between border-b border-cream pb-3"><span className="text-slate-500">Phone</span><span className="font-medium text-ink">+91 98765 43210</span></div>
          <div className="flex justify-between border-b border-cream pb-3"><span className="text-slate-500">College</span><span className="font-medium text-ink">Parvatibai Chowgule College</span></div>
          <div className="flex justify-between border-b border-cream pb-3"><span className="text-slate-500">Subscription</span>{subActive ? <StatusBadge status="Active" /> : <button onClick={() => go("subscription")} className="text-xs font-semibold text-brand">Subscribe</button>}</div>
          <div className="flex justify-between"><span className="text-slate-500">Saved routes</span><span className="font-medium text-ink">{SAVED_ROUTES.length}</span></div>
        </div>
        <GhostButton full className="mt-5" icon={LogOut} onClick={() => go("landing")}>Logout</GhostButton>
      </div>
    </div>
  );
}

/* =========================================================================
   Driver dashboard
   ========================================================================= */

function DriverDashboard({ go }) {
  const [tripActive, setTripActive] = useState(false);
  const idx = useGpsSimulation(tripActive, 1600);
  const stops = ROUTES["101"].via;
  const passedStops = STOP_POINT_INDEX.filter((pi) => idx >= pi).length;
  const nextStop = stops[Math.min(stops.length - 1, passedStops)];

  return (
    <div className="min-h-screen bg-ink font-body">
      <header className="flex items-center justify-between border-b border-white-10 px-5 py-4">
        <Logo dark />
        <button onClick={() => go("landing")} className="flex items-center gap-1 text-sm font-medium text-white-60"><LogOut className="h-4 w-4" />Logout</button>
      </header>

      <main className="mx-auto max-w-3xl px-5 py-8">
        <p className="text-white-60">Good afternoon, Driver</p>
        <h1 className="font-display text-2xl font-bold text-white">Rajesh Naik</h1>

        <div className="surface-1 mt-5 rounded-2xl border border-white-10 p-5">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-display text-xl font-bold text-white">BUS 101</div>
              <div className="text-sm text-white-50">GOA-07-AB-1234</div>
            </div>
            <StatusBadge status={tripActive ? "Active" : "Offline"} />
          </div>
          <div className="mt-3 text-sm text-white-60">Colva Beach → Kamat Hotel</div>

          {tripActive && (
            <div className="surface-1 mt-4 rounded-xl p-4">
              <TrackingMap selectedBus={ROUTES["101"]} idx={idx} />
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div><div className="text-white-40">Current location</div><div className="font-semibold text-white">Near {stops[Math.max(0, passedStops - 1)]}</div></div>
                <div><div className="text-white-40">Next stop</div><div className="font-semibold text-white">{nextStop}</div></div>
                <div><div className="text-white-40">Passengers waiting</div><div className="font-semibold text-white">12</div></div>
                <div><div className="text-white-40">ETA to next stop</div><div className="font-mono font-bold text-white">6 min</div></div>
              </div>
            </div>
          )}

          <div className="mt-5 flex flex-wrap gap-2">
            {!tripActive ? (
              <PrimaryButton icon={Play} onClick={() => setTripActive(true)}>Start Trip</PrimaryButton>
            ) : (
              <>
                <button onClick={() => setTripActive(false)} className="inline-flex items-center gap-2 rounded-xl bg-rose-600 px-5 py-3 font-semibold text-white hover:bg-rose-700"><Square className="h-4 w-4" />End Trip</button>
                <button className="side-btn inline-flex items-center gap-2 rounded-xl border border-white-15 px-5 py-3 font-semibold text-white"><Pause className="h-4 w-4" />Pause Tracking</button>
                <button className="side-btn inline-flex items-center gap-2 rounded-xl border border-white-15 px-5 py-3 font-semibold text-white"><AlertCircle className="h-4 w-4" />Report Issue</button>
              </>
            )}
          </div>
        </div>

        <div className="mt-6 flex items-center justify-between rounded-xl border border-dashed border-white-15 px-4 py-3 text-sm text-white-50">
          <span>Want to register another bus?</span>
          <button onClick={() => go("driverRegister")} className="font-semibold text-teal">Register a bus</button>
        </div>
      </main>
    </div>
  );
}

function DriverRegister({ go }) {
  const fields = ["Driver Name","Phone Number","Driver ID","Bus Number / Registration","Route","Starting Point","Destination","Major Stops","Operating Days","Operating Hours"];
  return (
    <div className="min-h-screen bg-ink px-5 py-8 font-body">
      <div className="mx-auto max-w-lg">
        <button onClick={() => go("driverHome")} className="mb-4 flex items-center gap-1 text-sm text-white-60"><ChevronLeft className="h-4 w-4" />Back</button>
        <h1 className="font-display text-2xl font-bold text-white">Register Your Bus</h1>
        <div className="mt-5 rounded-2xl bg-white p-6">
          <div className="grid gap-3 sm:grid-cols-2">
            {fields.map((f) => (
              <div key={f} className={f === "Major Stops" ? "sm:col-span-2" : ""}>
                <label className="mb-1 block text-xs font-semibold text-slate-500">{f}</label>
                <input placeholder={f} className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none" />
              </div>
            ))}
            <div className="sm:col-span-2">
              <label className="mb-1 block text-xs font-semibold text-slate-500">Bus Type</label>
              <select className="input-field w-full rounded-xl px-3 py-2.5 text-sm outline-none">
                {["Standard Bus","Mini Bus","Express Bus","Shuttle","AC Bus","Other"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <PrimaryButton full className="mt-5" onClick={() => go("driverHome")}>Submit for Approval</PrimaryButton>
          <p className="mt-2 text-center text-xs text-slate-400">Status after submission: <span className="font-semibold text-amber-600">Pending Admin Approval</span></p>
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Admin dashboard
   ========================================================================= */

const ADMIN_NAV = [
  { key: "adminHome", label: "Dashboard", icon: LayoutDashboard },
  { key: "adminBuses", label: "Buses", icon: Bus },
  { key: "adminDrivers", label: "Drivers", icon: Users },
  { key: "adminRoutes", label: "Routes", icon: RouteIcon },
  { key: "adminFleet", label: "Live Tracking", icon: MapIcon },
];

function AdminShell({ screen, go, children }) {
  return (
    <div className="flex min-h-screen bg-adminbg font-body">
      <aside className="hidden w-60 flex-col bg-ink p-4 md:flex">
        <div className="mb-8 px-2"><Logo dark /><div className="mt-1 pl-11 text-2xs font-semibold uppercase tracking-wider text-white-40">Admin</div></div>
        <nav className="space-y-1">
          {ADMIN_NAV.map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => go(key)} className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium ${screen === key ? "side-link-active" : "side-link"}`}>
              <Icon className="h-4 w-4" />{label}
            </button>
          ))}
        </nav>
        <div className="mt-auto space-y-1 border-t border-white-10 pt-3">
          <button className="side-link flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium"><Settings className="h-4 w-4" />Settings</button>
          <button onClick={() => go("landing")} className="side-link flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium"><LogOut className="h-4 w-4" />Logout</button>
        </div>
      </aside>
      <div className="flex-1 overflow-auto">
        <div className="flex items-center justify-between border-b border-cream bg-white px-6 py-4 md:hidden">
          <Logo /><span className="text-xs font-semibold text-slate-400">Admin</span>
        </div>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, accent }) {
  return (
    <div className="card-surface rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</span>
        <Icon className={`h-4 w-4 ${accent}`} />
      </div>
      <div className="mt-2 font-display text-2xl font-bold text-ink">{value}</div>
    </div>
  );
}

function MiniBarChart({ data }) {
  const max = Math.max(...data.map((d) => d.riders));
  return (
    <div className="flex h-40 items-end gap-3">
      {data.map((d) => (
        <div key={d.month} className="flex flex-1 flex-col items-center gap-2">
          <div className="w-full rounded-t-md bg-teal" style={{ height: `${(d.riders / max) * 120}px` }} />
          <span className="text-2xs font-medium text-slate-400">{d.month}</span>
        </div>
      ))}
    </div>
  );
}

function AdminHome({ go }) {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Admin Dashboard</h1>
      <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Registered Buses" value="128" icon={Bus} accent="text-brand" />
        <StatCard label="Active Buses" value="74" icon={Activity} accent="text-emerald-500" />
        <StatCard label="Registered Passengers" value="4,820" icon={Users} accent="text-sky-500" />
        <StatCard label="Active Subscribers" value="3,240" icon={ShieldCheck} accent="text-teal" />
        <StatCard label="Trips Today" value="1,245" icon={RouteIcon} accent="text-amber-500" />
        <StatCard label="Revenue" value="₹29,160/mo" icon={TrendingUp} accent="text-brand" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="card-surface lg:col-span-2 rounded-2xl p-5">
          <div className="mb-1 font-display font-bold text-ink">Ridership (last 6 months)</div>
          <MiniBarChart data={REVENUE_SERIES} />
        </div>
        <div className="card-surface rounded-2xl p-5">
          <div className="mb-3 font-display font-bold text-ink">Pending approvals</div>
          <div className="flex items-center justify-between rounded-xl bg-cream px-3 py-2.5 text-sm">
            <span className="font-medium text-ink">BUS 512 · Mapusa → Calangute</span>
            <StatusBadge status="Pending Admin Approval" />
          </div>
          <button onClick={() => go("adminDrivers")} className="mt-3 text-xs font-semibold text-brand">Review in Drivers →</button>
        </div>
      </div>
    </div>
  );
}

function AdminBuses() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Buses</h1>
      <div className="card-surface mt-4 overflow-x-auto rounded-2xl">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-cream bg-cream text-xs uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">Bus</th><th className="px-4 py-3">Registration</th><th className="px-4 py-3">Driver</th><th className="px-4 py-3">Route</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Actions</th></tr>
          </thead>
          <tbody>
            {ADMIN_BUSES.map((b) => (
              <tr key={b.bus} className="border-b border-cream last:border-0">
                <td className="px-4 py-3 font-semibold text-ink">BUS {b.bus}</td>
                <td className="px-4 py-3 font-mono text-xs text-slate-500">{b.reg}</td>
                <td className="px-4 py-3">{b.driver}</td>
                <td className="px-4 py-3">{b.route}</td>
                <td className="px-4 py-3"><StatusBadge status={b.status} /></td>
                <td className="px-4 py-3">
                  <div className="flex gap-2 text-xs font-semibold text-brand">
                    <button>View</button><button>Edit</button><button>Disable</button><button>Track</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminDrivers() {
  const drivers = [
    { name: "Rajesh Naik", id: "DRV-1001", bus: "101", phone: "98xxxxx210", trips: 342, approval: "Approved" },
    { name: "Suresh Fernandes", id: "DRV-1002", bus: "204", phone: "98xxxxx430", trips: 298, approval: "Approved" },
    { name: "Amol Gaonkar", id: "DRV-1042", bus: "512", phone: "98xxxxx877", trips: 0, approval: "Pending" },
  ];
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Drivers</h1>
      <div className="card-surface mt-4 overflow-x-auto rounded-2xl">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-cream bg-cream text-xs uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">Driver</th><th className="px-4 py-3">ID</th><th className="px-4 py-3">Bus</th><th className="px-4 py-3">Phone</th><th className="px-4 py-3">Trips</th><th className="px-4 py-3">Approval</th><th className="px-4 py-3">Actions</th></tr>
          </thead>
          <tbody>
            {drivers.map((d) => (
              <tr key={d.id} className="border-b border-cream last:border-0">
                <td className="px-4 py-3 font-semibold text-ink">{d.name}</td>
                <td className="px-4 py-3 font-mono text-xs text-slate-500">{d.id}</td>
                <td className="px-4 py-3">BUS {d.bus}</td>
                <td className="px-4 py-3">{d.phone}</td>
                <td className="px-4 py-3">{d.trips}</td>
                <td className="px-4 py-3">{d.approval === "Pending" ? <StatusBadge status="Pending Admin Approval" /> : <StatusBadge status="Active" />}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-2 text-xs font-semibold">
                    {d.approval === "Pending" ? (
                      <><button className="text-emerald-600">Approve</button><button className="text-rose-600">Reject</button></>
                    ) : <button className="text-amber-600">Suspend</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminRoutes() {
  const stops = ["Colva Beach", "Margao", "Maria Hall", "Kamat Hotel"];
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Routes</h1>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="card-surface rounded-2xl p-5">
          <div className="font-display font-bold text-ink">Route 101 · Colva Beach → Kamat Hotel</div>
          <div className="mt-4 space-y-0">
            {stops.map((s, i) => (
              <div key={s} className="flex items-center gap-3">
                <div className="flex flex-col items-center">
                  <span className="h-2.5 w-2.5 rounded-full bg-brand" />
                  {i < stops.length - 1 && <span className="h-6 w-px bg-slate-200" />}
                </div>
                <span className="-mt-1 pb-4 text-sm text-slate-600">{s}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <GhostButton small>Add Stop</GhostButton>
            <GhostButton small>Remove Stop</GhostButton>
            <GhostButton small>Edit Route</GhostButton>
          </div>
        </div>
        <div className="space-y-3">
          {[
            ["Route 102", "Margao → Navelim → Colva"],
            ["Route 203", "Margao → Verna → Cortalim → Panjim"],
            ["Route 304", "Vasco → Chicalim → Margao"],
            ["Route 405", "Mapusa → Calangute → Candolim"],
          ].map(([n, r]) => (
            <div key={n} className="card-surface flex items-center justify-between rounded-xl px-4 py-3">
              <div><div className="text-sm font-semibold text-ink">{n}</div><div className="text-xs text-slate-500">{r}</div></div>
              <ChevronRight className="h-4 w-4 text-slate-300" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminFleet() {
  const idx = useGpsSimulation(true, 1500);
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink">Live Fleet Tracking</h1>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2"><TrackingMap selectedBus={ROUTES["101"]} idx={idx} /></div>
        <div className="space-y-3">
          {Object.values(ROUTES).map((b) => (
            <div key={b.id} className="card-surface rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-ink">BUS {b.id}</span>
                <StatusBadge status={b.status} />
              </div>
              <div className="mt-1 text-xs text-slate-500">{b.from} → {b.to}</div>
              <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-slate-500">
                <div>Speed <span className="font-semibold text-ink">32 km/h</span></div>
                <div>Riders <span className="font-semibold text-ink">{b.passengers}</span></div>
                <div>ETA <span className="font-semibold text-ink">{b.eta} min</span></div>
                <div>Updated <span className="font-semibold text-ink">Just now</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   Root app
   ========================================================================= */

export default function BusrayApp() {
  const [screen, setScreen] = useState("landing");
  const [roleTab, setRoleTab] = useState("passenger");
  const [selectedBus, setSelectedBus] = useState(null);
  const [search, setSearch] = useState({ from: "Margao", to: "Kamat Hotel" });
  const [notifOpen, setNotifOpen] = useState(false);
  const [subActive, setSubActive] = useState(false);

  function go(next, tab, bus) {
    if (tab) setRoleTab(tab);
    if (bus) setSelectedBus(bus);
    setNotifOpen(false);
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  const passengerScreens = ["passengerHome","findBus","busResults","tracking","arrival","alternative","trips","saved","subscription","profile"];
  const adminScreens = ["adminHome","adminBuses","adminDrivers","adminRoutes","adminFleet"];

  let body;
  if (screen === "landing") body = <Landing go={go} />;
  else if (screen === "login") body = <Login go={go} roleTab={roleTab} setRoleTab={setRoleTab} />;
  else if (screen === "signup") body = <Signup go={go} />;
  else if (screen === "driverHome") body = <DriverDashboard go={go} />;
  else if (screen === "driverRegister") body = <DriverRegister go={go} />;
  else if (adminScreens.includes(screen)) {
    let inner;
    if (screen === "adminHome") inner = <AdminHome go={go} />;
    else if (screen === "adminBuses") inner = <AdminBuses />;
    else if (screen === "adminDrivers") inner = <AdminDrivers />;
    else if (screen === "adminRoutes") inner = <AdminRoutes />;
    else inner = <AdminFleet />;
    body = <AdminShell screen={screen} go={go}>{inner}</AdminShell>;
  } else if (passengerScreens.includes(screen)) {
    let inner;
    if (screen === "passengerHome") inner = <PassengerHome go={go} search={search} setSearch={setSearch} />;
    else if (screen === "findBus") inner = <PassengerHome go={go} search={search} setSearch={setSearch} />;
    else if (screen === "busResults") inner = <BusResults go={go} search={search} />;
    else if (screen === "tracking") inner = <BusTracking go={go} selectedBus={selectedBus} />;
    else if (screen === "arrival") inner = <BusArrival go={go} selectedBus={selectedBus} />;
    else if (screen === "alternative") inner = <AlternativeTransport go={go} selectedBus={selectedBus} />;
    else if (screen === "trips") inner = <MyTrips />;
    else if (screen === "saved") inner = <SavedRoutesScreen go={go} setSearch={setSearch} />;
    else if (screen === "subscription") inner = <Subscription subActive={subActive} setSubActive={setSubActive} />;
    else inner = <Profile go={go} subActive={subActive} />;
    body = (
      <PassengerShell screen={screen} go={go} notifOpen={notifOpen} setNotifOpen={setNotifOpen}>
        {inner}
      </PassengerShell>
    );
  } else body = <Landing go={go} />;

  return (
    <div>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap');

        :root {
          --c-brand: #C1502E;
          --c-brand-dark: #a8431f;
          --c-ink: #141B2E;
          --c-teal: #3FA79A;
          --c-cream: #FBF6EC;
          --c-cream-border: #EAE1CE;
          --c-tabbg: #EFE7D6;
          --c-mapbg: #EFF5F2;
          --c-adminbg: #F5F1E6;
        }

        .font-display { font-family: 'Space Grotesk', ui-sans-serif, sans-serif; }
        .font-body, body { font-family: 'Inter', ui-sans-serif, sans-serif; }
        .font-mono { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
        .text-2xs { font-size: 10px; line-height: 1.3; }

        @keyframes dashmove { to { stroke-dashoffset: -160; } }
        .route-dash { animation: dashmove 4s linear infinite; }
        .live-dot { background: var(--c-teal); animation: pulse 1.6s ease-in-out infinite; }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }

        .bg-cream { background-color: var(--c-cream); }
        .bg-mapbg { background-color: var(--c-mapbg); }
        .bg-adminbg { background-color: var(--c-adminbg); }
        .bg-ink { background-color: var(--c-ink); }
        .bg-brand { background-color: var(--c-brand); }
        .bg-teal { background-color: var(--c-teal); }
        .text-ink { color: var(--c-ink); }
        .text-brand { color: var(--c-brand); }
        .text-teal { color: var(--c-teal); }
        .border-cream { border-color: var(--c-cream-border); }
        .border-cream-border { border-color: var(--c-cream-border); }

        .card-surface { background-color: #fff; border: 1px solid var(--c-cream-border); }
        .badge-ink { background-color: var(--c-ink); }
        .teal-dot { background-color: var(--c-teal); }
        .brand-mark { background-color: var(--c-brand); }
        .ping-dot { background-color: var(--c-brand); box-shadow: 0 0 0 2px var(--c-cream); }
        .icon-btn:hover { background-color: #fff; }

        .nav-link { color: #475569; }
        .nav-link:hover { color: var(--c-ink); }

        .btn-primary { background-color: var(--c-brand); color: #fff; }
        .btn-primary:hover { background-color: var(--c-brand-dark); }

        .btn-ghost { background-color: #fff; border: 1px solid var(--c-cream-border); color: var(--c-ink); }
        .btn-ghost:hover { border-color: #cbd5e1; background-color: #f8fafc; }

        .bus-row { transition: border-color .15s ease; }
        .bus-row:hover { border-color: rgba(193,80,46,0.4); }

        .input-field { background-color: #fff; border: 1px solid #e2e8f0; }
        .input-field:focus-within { border-color: var(--c-brand); }
        .input-field input:focus, .input-field select:focus { outline: none; }

        .tabbar { background-color: var(--c-tabbg); }
        .tab-active { background-color: #fff; color: var(--c-ink); box-shadow: 0 1px 2px rgba(0,0,0,0.06); }

        .tag-brand-soft { background-color: rgba(193,80,46,0.1); color: var(--c-brand); }
        .pay-active { border-color: var(--c-brand); background-color: rgba(193,80,46,0.06); color: var(--c-brand); }

        .text-white-40 { color: rgba(255,255,255,0.4); }
        .text-white-50 { color: rgba(255,255,255,0.5); }
        .text-white-60 { color: rgba(255,255,255,0.6); }
        .border-white-10 { border-color: rgba(255,255,255,0.1); }
        .border-white-15 { border-color: rgba(255,255,255,0.15); }
        .surface-1 { background-color: rgba(255,255,255,0.05); }
        .side-btn:hover { background-color: rgba(255,255,255,0.06); }

        .side-link { color: rgba(255,255,255,0.55); }
        .side-link:hover { background-color: rgba(255,255,255,0.06); color: #fff; }
        .side-link-active { background-color: rgba(255,255,255,0.12); color: #fff; }
      `}</style>
      {body}
    </div>
  );
}
